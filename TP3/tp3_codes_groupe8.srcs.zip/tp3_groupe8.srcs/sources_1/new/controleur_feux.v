-- Entité principale du contrôleur de carrefour
entity controleur_feux is
    port (
        CLK     : in bit;                  -- Horloge 100 MHz
        BTN_C   : in bit;                  -- Signal de reset
        LED_3_0 : out bit_vector(3 downto 0); -- Feux axe 1 (0, Rouge, Orange, Vert)
        LED_7_4 : out bit_vector(3 downto 0)  -- Feux axe 2 (0, Rouge, Orange, Vert)
    );
end controleur_feux;


architecture Behavioral of controleur_feux is


    -- Déclaration du composant diviseur de fréquence (Exercice 1)
    component clock_divider
        generic(divisor : integer);
        port(
            clock_in  : in bit;
            reset     : in bit;
            clock_out : out bit
        );
    end component;


    -- Signal pour l'horloge interne à 1 Hz
    signal clk_1Hz : bit;


    -- Définition des états de la machine
    type state_type is (PHASE_1, PHASE_2, PHASE_3, PHASE_4);
    signal etat_courant : state_type := PHASE_1;


    -- Compteur pour gérer la durée des phases (jusqu'à 8 secondes)
    signal compteur : integer range 0 to 10 := 0;


begin


    -- Instanciation du diviseur de fréquence pour générer une horloge à 1 Hz
    -- (100 000 000 cycles d'une horloge à 100 MHz = 1 seconde)
    diviseur_inst : clock_divider
        generic map (divisor => 100000000)
        port map (
            clock_in  => CLK,
            reset     => '0',      -- On laisse le diviseur tourner en permanence
            clock_out => clk_1Hz
        );


    -- Processus séquentiel : Gestion des transitions d'états et du temps
    process(clk_1Hz, BTN_C)
    begin
        if BTN_C = '1' then
            -- Reset asynchrone (pour répondre à Q3 avant la modif synchrone de Q6)
            etat_courant <= PHASE_1;
            compteur <= 0;

        elsif clk_1Hz'event and clk_1Hz = '1' then
            -- Incrémentation du compteur de secondes à chaque front d'horloge 1 Hz
            compteur <= compteur + 1;

            case etat_courant is
                when PHASE_1 =>
                    -- Phase 1 : Axe 1 Vert, Axe 2 Rouge (Durée : 8s)
                    if compteur >= 7 then -- De 0 à 7 = 8 secondes écoulées
                        etat_courant <= PHASE_2;
                        compteur <= 0;
                    end if;

                when PHASE_2 =>
                    -- Phase 2 : Axe 1 Orange, Axe 2 Rouge (Durée : 2s)
                    if compteur >= 1 then -- De 0 à 1 = 2 secondes écoulées
                        etat_courant <= PHASE_3;
                        compteur <= 0;
                    end if;

                when PHASE_3 =>
                    -- Phase 3 : Axe 1 Rouge, Axe 2 Vert (Durée : 8s)
                    if compteur >= 7 then
                        etat_courant <= PHASE_4;
                        compteur <= 0;
                    end if;

                when PHASE_4 =>
                    -- Phase 4 : Axe 1 Rouge, Axe 2 Orange (Durée : 2s)
                    if compteur >= 1 then
                        etat_courant <= PHASE_1;
                        compteur <= 0;
                    end if;
            end case;
        end if;
    end process;


    -- Processus combinatoire : Affectation des sorties LED selon l'état courant
    -- Encodage choisi : "0" & "R" & "O" & "V"
    process(etat_courant)
    begin
        case etat_courant is
            when PHASE_1 =>
                LED_3_0 <= "0001"; -- Axe 1: Vert allumé
                LED_7_4 <= "0100"; -- Axe 2: Rouge allumé

            when PHASE_2 =>
                LED_3_0 <= "0010"; -- Axe 1: Orange allumé
                LED_7_4 <= "0100"; -- Axe 2: Rouge allumé

            when PHASE_3 =>
                LED_3_0 <= "0100"; -- Axe 1: Rouge allumé
                LED_7_4 <= "0001"; -- Axe 2: Vert allumé

            when PHASE_4 =>
                LED_3_0 <= "0100"; -- Axe 1: Rouge allumé
                LED_7_4 <= "0010"; -- Axe 2: Orange allumé
        end case;
    end process;


end Behavioral;
