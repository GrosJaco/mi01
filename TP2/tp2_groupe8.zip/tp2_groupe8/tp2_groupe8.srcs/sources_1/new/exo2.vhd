----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 09/22/2026 08:19:44 PM
-- Design Name: 
-- Module Name: exo2 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity exo2 is
    Port (
        BTN_D : in  STD_LOGIC;                    -- Horloge (front montant)
        BTN_G : in  STD_LOGIC;                    -- Reset synchrone (actif à '1')
        LED_1_0 : out STD_LOGIC_VECTOR (1 downto 0) -- Valeur du compteur
    );
end exo2;

architecture Behavioral of exo2 is
    signal count : STD_LOGIC_VECTOR(1 downto 0) := "00";
begin

    -- Remarque : BTN_G n'est PAS dans la liste de sensibilité
    process(BTN_D)
    begin
        if rising_edge(BTN_D) then -- ou (BTN_D'event and BTN_D = '1')
            if BTN_G = '1' then
                count <= "00";     -- Reset appliqué uniquement sur front d'horloge
            else
                count <= count + 1; -- Incrémentation si pas de reset
            end if;
        end if;
    end process;

    LED_1_0 <= count;

end Behavioral;
