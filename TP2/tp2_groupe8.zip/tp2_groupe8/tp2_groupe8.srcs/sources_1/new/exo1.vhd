----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 09/22/2026 07:22:19 PM
-- Design Name: 
-- Module Name: exo1 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL; -- Permet de faire l'addition '+' directement sur du std_logic_vector

entity exo1 is
    Port (
        BTN_D : in  STD_LOGIC;                    -- Horloge
        BTN_G : in  STD_LOGIC;                    -- Reset asynchrone
        LED_1_0 : out STD_LOGIC_VECTOR (1 downto 0) -- Compteur
    );
end exo1;

architecture Behavioral of exo1 is
    signal count : STD_LOGIC_VECTOR(1 downto 0) := "00";
begin

    -- Le process est obligatoire pour réagir sur un front d'horloge
    process(BTN_D, BTN_G)
    begin
        if BTN_G = '1' then
            count <= "00";
        elsif BTN_D'event and BTN_D = '1' then -- Syntaxe classique/débutant pour le front montant
            count <= count + 1;
        end if;
    end process;

    LED_1_0 <= count;

end Behavioral;